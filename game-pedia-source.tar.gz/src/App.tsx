import { useEffect, useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Home from '@/pages/Home';
import Browse from '@/pages/Browse';
import GameDetail from '@/pages/GameDetail';
import type { Filters, Game, Platform } from '@/lib/types';
import { fetchGames, fetchPlatforms } from '@/lib/games';

function parseRoute(hash: string): { name: 'home' | 'browse' | 'game'; slug?: string } {
  const clean = hash.replace(/^#/, '');
  if (clean.startsWith('/game/'))
    return { name: 'game', slug: clean.slice('/game/'.length) };
  if (clean.startsWith('/browse')) return { name: 'browse' };
  return { name: 'home' };
}

const DEFAULT_FILTERS: Filters = {
  search: '',
  genres: [],
  tags: [],
  platforms: [],
  maxPrice: null,
  onSaleOnly: false,
  freeOnly: false,
  sort: 'relevance',
};

export default function App() {
  const [route, setRoute] = useState(() => parseRoute(window.location.hash));
  const [games, setGames] = useState<Game[]>([]);
  const [platforms, setPlatforms] = useState<Platform[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<Filters>(DEFAULT_FILTERS);

  useEffect(() => {
    const onHashChange = () => {
      setRoute(parseRoute(window.location.hash));
      window.scrollTo(0, 0);
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [gameData, platformData] = await Promise.all([
          fetchGames(),
          fetchPlatforms(),
        ]);
        if (!cancelled) {
          setGames(gameData);
          setPlatforms(platformData);
        }
      } catch (e) {
        if (!cancelled)
          setError(
            e instanceof Error ? e.message : 'Something went wrong loading games.'
          );
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const navigate = (path: string) => {
    window.location.hash = path;
  };

  const openGame = (slug: string) => navigate(`/game/${slug}`);

  const searchChanged = (value: string) => {
    setFilters((f) => ({ ...f, search: value }));
  };

  const goBrowse = () => navigate('/browse');

  let content: React.ReactNode;
  if (loading) {
    content = (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-white/10 border-t-sky-400" />
      </div>
    );
  } else if (error) {
    content = (
      <div className="mx-auto max-w-7xl px-4 py-20 text-center sm:px-6">
        <p className="text-lg font-semibold text-white">
          We couldn't load the game library
        </p>
        <p className="mt-2 text-sm text-gray-500">{error}</p>
        <button
          onClick={() => window.location.reload()}
          className="mt-6 rounded-md bg-sky-500 px-5 py-2.5 text-sm font-bold text-white hover:bg-sky-400"
        >
          Try again
        </button>
      </div>
    );
  } else if (route.name === 'game') {
    const game = games.find((g) => g.slug === route.slug);
    if (game) {
      const related = games
        .filter(
          (g) =>
            g.slug !== game.slug &&
            g.genres.some((gen) => game.genres.includes(gen))
        )
        .slice(0, 5);
      content = (
        <GameDetail
          game={game}
          related={related}
          onOpenGame={openGame}
          onBack={() => navigate('/')}
        />
      );
    } else {
      content = (
        <div className="mx-auto max-w-7xl px-4 py-20 text-center sm:px-6">
          <p className="text-lg font-semibold text-white">Game not found</p>
          <button
            onClick={goBrowse}
            className="mt-6 rounded-md bg-sky-500 px-5 py-2.5 text-sm font-bold text-white hover:bg-sky-400"
          >
            Browse all games
          </button>
        </div>
      );
    }
  } else if (route.name === 'browse') {
    content = (
      <Browse
        games={games}
        platforms={platforms}
        filters={filters}
        onFiltersChange={setFilters}
        onOpenGame={openGame}
      />
    );
  } else {
    content = (
      <Home games={games} onOpenGame={openGame} onBrowse={goBrowse} />
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#0e0e12] font-sans text-white">
      <Header
        route={route.name === 'game' ? '/' : `/${route.name}`}
        onNavigate={navigate}
        search={filters.search}
        onSearch={searchChanged}
      />
      <main className="flex-1">{content}</main>
      <Footer />
    </div>
  );
}
